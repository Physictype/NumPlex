from numplex import complex
from numplex import convert_to_polar as ctp
from numplex import convert_to_rectangular as ctr
import numpy as np
testcplx = complex(1,1)

print(~testcplx*testcplx)
a=complex(10000000,10000000999999999999999,True)
print(ctr(a))
print(complex(1,1)+3)