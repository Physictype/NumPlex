NumPlex Numpy Compatable Complex Library
* operators (+ - * / ~)

Examples
	from numplex import complex, ctp, ctr
	print(complex(3,3)+complex(1,1))
	–––
	from numplex import complex, ctp, ctr
	print(ctr(complex(3,3)))